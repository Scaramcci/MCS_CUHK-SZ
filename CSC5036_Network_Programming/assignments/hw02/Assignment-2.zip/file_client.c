// file_client.c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define BUFFER_SIZE 1024

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <filename>\n", argv[0]);
        return 1;
    }

    struct sockaddr_in serv_addr;
    int sock = 0;
    char buffer[BUFFER_SIZE] = {0};

    /* TODO: socket()
    * Create a socket using socket(AF_INET, SOCK_STREAM, 0)
    * Store the result in 'sock' variable
    * Print an error message and exit if it fails
    */

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);

    /* TODO: inet_pton()
    * Convert the IP address "127.0.0.1" from text to binary form
    * Use inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr)
    * Print an error message and exit if conversion fails (returns <= 0)
    */
    

    /* TODO: connect()
    * Connect to the server.
    */

    /* IMPLEMENTING SIMPLE FILE TRANSFER */

    // Variables you may need to declare:
    // FILE *file;
    // char *base_filename;

    /* TODO: Open file for reading in binary mode
    * Use fopen() with "rb" mode
    */

    /* TODO: Extract filename from path (argv[1])
    * Use strrchr() to find the last '/' in the path
    * Example: "../file1.zip" -> "file1.zip"
    * If no '/' found, use the entire path as filename
    * Store result in base_filename
    */

    /* TODO: Send filename to server
    * Send the filename (padded to BUFFER_SIZE) so server knows what to name the file
    */

    // You can add a small delay to avoid data mix-up

    /* TODO: Send file content
    * Read file in chunks of BUFFER_SIZE and send each chunk
    */

    // printf("File '%s' uploaded successfully.\n", base_filename);

    /* TODO: Close file and socket */

    return 0;
}