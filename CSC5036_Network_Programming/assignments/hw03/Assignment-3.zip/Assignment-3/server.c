#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include "network.h"
#include "utils.h"
#include "server.h"
#include <stdio.h>
#include <dirent.h>
#include <pthread.h>


void *server(void *arg) {
  serverArg_t *_arg = (serverArg_t *)arg;
  IDlist_t *idList = _arg->idList;
  int portNum = _arg->port;
  char *directory = _arg->directory;
  neighbors_t *neighbors = _arg->neighbors;
  pthread_mutex_t *mutex = _arg->lock;

  int socketfd = createNewSock();
  packet_t packet;
  unsigned long clientIpAddress;

  if (bindSocket(socketfd, portNum) == -1){
    ERROR("Error: wrong port binding. \n");
  }
  printf("[CONNECT] Successfully bind with the port: %d\n", portNum);

  while (1) {
    // TODO: receive packet
    // Hint: You can reuse the functions provided in network.c.
  
    unsigned char type = packet.descriptor;   

    char *packetType;
    switch(type) {
      case 0: packetType = "CONNECT"; break;
      case 1: packetType = "QUERY"; break;
      case 2: packetType = "RESPONSE"; break;
    }
    printf("[SERVER INFO] Received new packet: %s packet\n", packetType);

    if (type == CONNECT){
      // TODO: handle server connect
      
    }
    else if (type == QUERY){
      // TODO: handle server query
      
    }
    else if (type == RESPONSE){
      // TODO: handle server response
      
    }
  }
}

int serverHandleConnect(neighbors_t *neighbors, packet_t *packet, pthread_mutex_t *mutex) {
  unsigned long hostIpAddress;
  int portNum;
  /*
   * TODO: update neighbor list
   * Hint: functions in utils.c and network.c may be helpful
   * Hint: use mutex to ensure thread safety
   */

  // Your code starts here

  // Your code ends here

  printf("[NEIGHBOR] New neighbor connecting request. From address: %s:%d\n", 
    getHostIp(hostIpAddress), portNum);

  printf("[NEIGHBOR] New neighbor connected!\n");
  return 0;
}

int serverHandleQuery(serverArg_t *args, packet_t *packet) {
  /*
   * Handle QUERY packets using the steps below.
   * Hint: Ensure thread safety when accessing shared data.
   * You may add control flow around the provided log statements
   * so that each message is printed only when appropriate.
   */

  
  // TODO: If the ID is already recorded, print the message below and return.
  // Otherwise, record the ID and continue processing.

  printf("[DUPLICATE ID] Duplicate packet with ID %d detected. Ignoring and discarding.\n", packet->ID);

  // TODO: if file found in directory, return the msg back to query host

  printf("[RESPON] File %s found, responding to query.\n", packet->message);
    
  // TODO: TTL check
  
  printf("[TTL] Packet TTL expired, stopping forwarding.\n");
  
  // TODO: else not found, flood to neighbors

  printf("[TTL] Forwarding packet with TTL=%d\n", packet->TTL);
  
  return 0;
}

int serverHandleResponse(packet_t *packet) {
  printf("\n[FILE] File %s found on address %s, with port %d\n\n",
          packet->message, packet->hostname,
          packet->port);
  return 0;
}
