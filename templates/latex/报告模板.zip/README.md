# CUHK-Shenzhen Academic Report Template

This is an **unofficial**, English-language article/report template adapted for coursework at The Chinese University of Hong Kong, Shenzhen. It uses the crest image from the separately supplied `CUHK-beamer.zip`. The crest identifies the institution; this template is not an official university publication or endorsement.

## Compile

Unzip the archive, keep `assets/CUHK_Logo.png` beside `main.tex`, and run:

```sh
latexmk -xelatex -interaction=nonstopmode -halt-on-error main.tex
```

For a manual build, run `xelatex main.tex` twice. If you add verified citations, uncomment the two bibliography lines near the end of `main.tex`, then run `xelatex main.tex`, `bibtex main`, and `xelatex main.tex` twice. The sample uses no external bibliography entries.

## Adapt

1. Edit `\ReportCourse`, `\ReportType`, `\ReportTitle`, `\ReportAuthor`, `\ReportID`, `\ReportDate`, and `\ShortTitle` near the top of `main.tex`.
2. Replace all illustrative body text, sample code, and the notation table with material relevant to the assignment. Remove the abstract or conclusion if not requested.
3. Put figures in a project folder and use `\includegraphics`. Keep captions and labels; refer to figures, tables, and equations in the text.
4. Add only real, checked sources to `references.bib`, uncomment the bibliography lines, and cite them with `\citep{key}`. No citation or result is provided by this template.
5. Render and inspect every page of the final PDF. Keep the source files and any assets needed to reproduce it.

For DDA5001 HW1, the final written answers must be in English, and the teacher requests a PDF plus `.py` files in one ZIP. Problem 3 also requests numerical outputs. The AI-collaboration cases for Problems 3 and 5 must document real interactions and verification evidence, at most one page each and two pages together. Consult the assignment PDF for all requirements.

## Files

- `main.tex`: article-style report with examples of mathematics, tables, code, and commented patterns for figures and bibliography.
- `assets/CUHK_Logo.png`: crest copied from the supplied CUHK Beamer template.
- `references.bib`: empty bibliography scaffold; add verified sources only.

The original NKU sample content and assets were removed.
