"""Student release: implement the core of HW2 Problem 2(b) with a coding agent.

X: (n, d), one_hot: (n, K), theta: (d, K).
The last column of X is a constant feature. There is no separate bias b.
Use the analytic gradient from Problem 2(a) and implement updates yourself.
Do not use a ready-made classifier or optimizer for the required experiment.
You may use autodiff only as an independent check, not for training.

Preserve these function signatures. Do not mutate input arrays in place.
Edit this file, not framework.py, run.py, or the fixed experiment settings.
"""

import numpy as np


def softmax(logits):
    """Return stable row-wise probabilities for an (n, K) score matrix.

    Subtract each row's maximum before exponentiation. Explain to your agent
    why this leaves the probabilities unchanged.
    """
    raise NotImplementedError("Implement stable softmax with your coding agent.")


def cross_entropy(logits, one_hot):
    """Return scalar mean cross-entropy for one-hot labels, without L2 penalty.

    Compute stable log-probabilities from logits rather than log(softmax),
    which can become log(0). Do not clip probabilities to hide instability.
    """
    raise NotImplementedError("Implement the cross-entropy from Problem 2(a).")


def gradient(theta, X, one_hot):
    """Return the analytic mean-loss gradient derived in 2(a), shape (d, K).

    Preserve the lecture convention: class parameters are COLUMNS of theta.
    """
    raise NotImplementedError("Implement your analytic matrix gradient.")


def gd_step(theta, learning_rate, grad_fn):
    """Return one full-batch GD update; grad_fn(parameter) returns its gradient."""
    raise NotImplementedError("Implement one GD update.")


def momentum_step(theta, previous, learning_rate, beta, grad_fn):
    """Return one lecture Polyak-momentum update.

    theta is the current parameter; previous is the preceding parameter.
    Think about WHERE the gradient is evaluated.
    """
    raise NotImplementedError("Implement one momentum update.")


def nesterov_step(theta, previous, learning_rate, k, grad_fn):
    """Return one lecture Nesterov update, using coefficient (k-1)/(k+2).

    k is the 1-based update number, so the first coefficient is zero.
    Think about WHERE the gradient is evaluated, not just its coefficient.
    """
    raise NotImplementedError("Implement one Nesterov update.")
