"""Small independent checks for the P3 instructor solution.

Run: python -m unittest discover -s p3 -p 'test_*.py' -v
from the code_solution directory, or run this file directly.
"""

import unittest
from unittest.mock import patch

import numpy as np

import p3


class RobustRegressionTests(unittest.TestCase):
    def test_exact_shifted_huber_branches_and_boundaries(self):
        for mu in (1.0, 1e-5):
            for r, value, derivative in [
                (-2., 2., -1.), (-1., 1., -1.), (-0.5, 0.625, -0.5),
                (0., 0.5, 0.), (0.5, 0.625, 0.5), (1., 1., 1.),
                (2., 2., 1.),
            ]:
                with self.subTest(mu=mu, residual=r):
                    self.assertAlmostEqual(
                        p3.huber_loss([r * mu], [[1.]], [[0.]], mu) / mu,
                        value, places=12)
                    np.testing.assert_allclose(
                        p3.huber_gradient([r * mu], [[1.]], [[0.]], mu),
                        [derivative], atol=1e-12)

    def test_vector_shapes_prevent_column_broadcasting(self):
        X = np.array([[1., 2.], [3., 1.], [0., 1.]])
        y = np.array([1., 0., 2.])
        theta = np.array([0.2, -0.5])
        self.assertEqual(p3.huber_gradient(theta[:, None], X, y[:, None], 1.).shape,
                         (2,))
        self.assertEqual(p3.least_squares(X, y[:, None]).shape, (2,))
        self.assertEqual(p3.huber_loss(theta, X, y, 1.),
                         p3.huber_loss(theta[:, None], X, y[:, None], 1.))
        np.testing.assert_allclose(p3.huber_gradient(theta, X, y, 1.),
                                   p3.huber_gradient(theta[:, None], X, y[:, None], 1.))

    def test_coordinate_finite_differences_for_both_mu_values(self):
        X = np.array([[1., 0.], [0., 1.], [1., 1.], [1., -1.], [1., 2.]])
        for mu in (1., 1e-5):
            theta = np.zeros(2)
            y = -mu * np.array([-2., -0.5, 0., 0.5, 2.])
            step = 1e-3 * mu
            finite_difference = []
            for j in range(2):
                offset = np.eye(2)[j] * step
                finite_difference.append(
                    (p3.huber_loss(theta + offset, X, y, mu)
                     - p3.huber_loss(theta - offset, X, y, mu)) / (2 * step))
            np.testing.assert_allclose(p3.huber_gradient(theta, X, y, mu),
                                       finite_difference, atol=1e-9, rtol=1e-9)
            # Independent hand calculation using the five branch derivatives.
            np.testing.assert_allclose(p3.huber_gradient(theta, X, y, mu),
                                       [0.5, 1.0], atol=1e-12)

    def test_validation_detects_a_wrong_mean_gradient(self):
        X = np.array([[1., 0.], [0., 1.], [1., 1.], [1., -1.], [1., 2.]])
        y = -np.array([-2., -0.5, 0., 0.5, 2.])
        direction = np.array([3., 4.]) / 5
        correct = p3.huber_gradient
        with patch.object(p3, "huber_gradient",
                          side_effect=lambda theta, X, y, mu: correct(theta, X, y, mu) / len(y)):
            row = p3.gradient_checks(X, y, np.zeros(2), 1., direction, [1e-3])[0]
        self.assertGreater(row["finite_difference_abs_error"], 0.8)

    def test_local_taylor_remainder_and_sum_mean_factor(self):
        X = np.array([[1., 0.], [0., 1.], [1., 1.], [1., -1.], [1., 2.]])
        for mu in (1., 1e-5):
            rows = p3.gradient_checks(
                X, -mu * np.array([-2., -0.5, 0., 0.5, 2.]), np.zeros(2),
                mu, [3., 4.], mu * np.array([0.1, 0.01, 0.001]))
            for row in rows:
                # No crossing at these steps: inner-branch curvature gives
                # R(t) = 0.5*(0.8**2 + 1.4**2 + (-0.2)**2)*t**2/mu.
                self.assertAlmostEqual(row["taylor_abs_error"] / mu,
                                       1.32 * row["step_over_mu"] ** 2, places=12)
                self.assertLess(row["finite_difference_abs_error"], 1e-9)
                self.assertAlmostEqual(row["gradient_dot_direction"], 1.1)
                self.assertAlmostEqual(row["mean_gradient_dot_direction"], 0.22)
                self.assertAlmostEqual(row["mean_directional_finite_difference"],
                                       0.22, places=9)
                self.assertLess(row["mean_finite_difference_abs_error"], 1e-9)
                self.assertAlmostEqual(row["sum_to_mean_finite_difference_ratio"],
                                       5., places=9)
                self.assertAlmostEqual(row["mean_scaling_abs_error"], 0.88, places=9)

    def test_sum_mean_ratio_is_omitted_for_zero_derivative(self):
        row = p3.gradient_checks([[1.]], [0.], [0.], 1., [1.], [0.01])[0]
        self.assertAlmostEqual(row["mean_directional_finite_difference"], 0.)
        self.assertIsNone(row["sum_to_mean_finite_difference_ratio"])

    def test_stable_least_squares_without_an_inverse(self):
        X = np.array([[1., 1.], [1., 1. + 1e-9], [1., 1. - 1e-9]])
        expected = np.array([2., -3.])
        y = X @ expected
        with patch.object(np.linalg, "inv", side_effect=AssertionError("Do not invert X.T @ X")):
            actual = p3.least_squares(X, y)
        np.testing.assert_allclose(actual, expected, rtol=1e-6, atol=1e-6)
        # A singular design also has a well-defined minimum-norm LS answer.
        np.testing.assert_allclose(p3.least_squares([[1., 1.], [2., 2.]], [2., 4.]),
                                   [1., 1.], atol=1e-12)

    def test_exact_update_count_and_history(self):
        initial = np.array([0.])
        final, history, losses = p3.gradient_descent(
            [[1.]], [2.], initial, mu=1., alpha=0.1, steps=3)
        np.testing.assert_allclose(history[:, 0], [0., 0.1, 0.2, 0.3])
        np.testing.assert_allclose(final, [0.3])
        np.testing.assert_allclose(losses, [2., 1.9, 1.8, 1.7])
        np.testing.assert_array_equal(initial, [0.])
        final, history, losses = p3.gradient_descent(
            [[1.]], [2.], initial, mu=1., steps=0)
        self.assertEqual(history.shape, (1, 1))
        self.assertEqual(losses.shape, (1,))
        np.testing.assert_array_equal(final, initial)


if __name__ == "__main__":
    unittest.main()
