"""Instructor checks: run `python -m unittest discover -s p5 -p 'test_p5.py'`."""

import csv
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

import p5


class PocketTests(unittest.TestCase):
    def setUp(self):
        self.X = np.array([[1., 0., 0.], [1., 0., 0.],
                           [1., 0., 0.], [1., 1., 0.]])
        self.y = np.array([1, -1, 1, -1])

    def test_score_zero_predicts_positive(self):
        X = np.array([[1., -1., 0.], [1., 0., 0.], [1., 1., 0.]])
        np.testing.assert_array_equal(p5.predict(np.array([0., 1., 0.]), X),
                                      [-1, 1, 1])

    def test_separable_early_stop(self):
        X = np.array([[1., 1., 0.], [1., -1., 0.]])
        y = np.array([1, -1])
        history = p5.train_pocket(X, y, max_updates=2000, seed=0)
        self.assertEqual(history["update"][-1], 1)
        self.assertEqual(history["current_train_error"][-1], 0)
        self.assertEqual(history["pocket_train_error"][-1], 0)
        self.assertEqual(len(history["update"]), 2)

    def test_initial_state_and_zero_updates(self):
        history = p5.train_pocket(self.X, self.y, max_updates=0)
        np.testing.assert_array_equal(history["update"], [0])
        np.testing.assert_array_equal(history["current_weights"], [[0., 0., 0.]])
        self.assertEqual(history["current_train_error"][0], .5)
        self.assertEqual(history["chosen_index"][0], -1)

    def test_nonseparable_six_updates_and_actual_trace(self):
        history = p5.train_pocket(self.X, self.y, max_updates=6, seed=0)
        self.assertEqual(len(history["update"]), 7)
        self.assertEqual(history["update"][-1], 6)
        np.testing.assert_array_equal(history["chosen_index"], [-1, 3, 2, 1, 2, 1, 0])
        np.testing.assert_array_equal(history["current_weights"],
                                      [[0, 0, 0], [-1, -1, 0], [0, -1, 0],
                                       [-1, -1, 0], [0, -1, 0], [-1, -1, 0], [0, -1, 0]])
        np.testing.assert_array_equal(history["pocket_weights"],
                                      [[0, 0, 0], [0, 0, 0], [0, -1, 0],
                                       [0, -1, 0], [0, -1, 0], [0, -1, 0], [0, -1, 0]])
        np.testing.assert_array_equal(history["current_train_error"],
                                      [.5, .5, .25, .5, .25, .5, .25])
        np.testing.assert_array_equal(history["pocket_train_error"],
                                      [.5, .5, .25, .25, .25, .25, .25])
        p5.audit_training_history(history, self.X, self.y)

    def test_each_update_uses_a_current_mistake(self):
        history = p5.train_pocket(self.X, self.y, max_updates=20, seed=0)
        for k in range(1, len(history["update"])):
            index = history["chosen_index"][k]
            previous = history["current_weights"][k - 1]
            self.assertNotEqual(p5.predict(previous, self.X[index:index + 1])[0],
                                self.y[index])
            np.testing.assert_allclose(history["current_weights"][k],
                                       previous + self.y[index] * self.X[index])

    def test_pocket_cumulative_min_and_audit_detects_corruption(self):
        history = p5.train_pocket(self.X, self.y, max_updates=30, seed=12)
        np.testing.assert_allclose(history["pocket_train_error"],
                                   np.minimum.accumulate(history["current_train_error"]))
        self.assertTrue(np.all(np.diff(history["pocket_train_error"]) <= 0))
        history["pocket_train_error"][-1] = .75
        with self.assertRaises(AssertionError):
            p5.audit_training_history(history, self.X, self.y)

    def test_pocket_is_copy_and_ties_retain_first_best(self):
        theta = np.array([1., 2., 3.])
        old = np.zeros(3)
        pocket, error = p5.update_pocket(theta, .25, old, .5)
        self.assertFalse(np.shares_memory(theta, pocket))
        theta[:] = 99
        np.testing.assert_array_equal(pocket, [1, 2, 3])
        tied, error = p5.update_pocket(theta, .25, pocket, .25)
        np.testing.assert_array_equal(tied, [1, 2, 3])
        self.assertEqual(error, .25)
        self.assertFalse(np.shares_memory(tied, pocket))

    def test_perceptron_step_does_not_mutate_input(self):
        theta = np.zeros(3)
        updated = p5.perceptron_step(theta, np.array([1., 2., 3.]), -1)
        np.testing.assert_array_equal(theta, [0, 0, 0])
        np.testing.assert_array_equal(updated, [-1, -2, -3])
        self.assertFalse(np.shares_memory(theta, updated))

    def test_history_snapshots_do_not_alias(self):
        history = p5.train_pocket(self.X, self.y, max_updates=6, seed=0)
        initial = history["current_weights"][0].copy()
        pocket = history["pocket_weights"].copy()
        second = history["current_weights"][1].copy()
        history["current_weights"][-1, :] = 123
        np.testing.assert_array_equal(history["current_weights"][0], initial)
        np.testing.assert_array_equal(history["current_weights"][1], second)
        np.testing.assert_array_equal(history["pocket_weights"], pocket)

    def test_test_labels_do_not_change_training_or_select_pocket(self):
        history = p5.train_pocket(self.X, self.y, max_updates=6, seed=0)
        frozen = {key: value.copy() for key, value in history.items()}
        first = p5.evaluate_test_history(history, self.X, self.y)
        flipped = p5.evaluate_test_history(history, self.X, -self.y)
        for key in history:
            np.testing.assert_array_equal(history[key], frozen[key])
        np.testing.assert_allclose(first["pocket_test_error"] +
                                   flipped["pocket_test_error"], 1)
        repeated = p5.train_pocket(self.X, self.y, max_updates=6, seed=0)
        for key in history:
            np.testing.assert_array_equal(history[key], repeated[key])

    def test_feature_mapping_and_bias(self):
        images = np.array([[[0., 1.], [0., 1.]],
                           [[1., 1.], [1., 1.]],
                           [[0., 0.], [0., 0.]]])
        features, y = p5.cal_feature_cls(images, np.array([1, 6, 2]))
        np.testing.assert_array_equal(y, [1, -1])
        np.testing.assert_allclose(features, [[.5, 1.], [1., 0.]])
        np.testing.assert_allclose(p5.add_bias(features), [[1., .5, 1.], [1., 1., 0.]])

    def test_toy_trace_is_saved_before_audit_failure(self):
        with tempfile.TemporaryDirectory() as output_dir:
            with patch.object(p5, "audit_training_history",
                              side_effect=AssertionError("Simulated failed audit")):
                with self.assertRaisesRegex(AssertionError, "Simulated failed audit"):
                    p5.run_toy_audit(output_dir)
            with (Path(output_dir) / "toy_trace.csv").open(newline="") as handle:
                rows = list(csv.DictReader(handle))
            self.assertEqual(len(rows), 7)
            self.assertEqual(rows[0]["update"], "0")
            self.assertEqual(rows[-1]["update"], "6")
            self.assertEqual(float(rows[3]["current_train_error"]), .5)
            self.assertEqual(float(rows[3]["pocket_train_error"]), .25)


if __name__ == "__main__":
    unittest.main()
