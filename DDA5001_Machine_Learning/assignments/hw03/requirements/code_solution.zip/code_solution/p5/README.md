# P5 instructor solution

`p5.py` completes the three student TODOs: `perceptron_step`, `update_pocket`, and the two training-error guarantees in `audit_training_history`. All other scaffold code matches the student version. Pocket retains a copy of the first best training model; current weights keep following their own perceptron trajectory. Test data are loaded and evaluated only after training finishes.

## Run and check

From this directory, with NumPy, SciPy, and Matplotlib installed:

```bash
python p5.py
python p5.py --audit-only --output-dir toy_outputs
python -m unittest discover -s . -p 'test_p5.py' -v
```

The default is seed 0, at most 2000 mistake updates, and output directory `outputs/` beside the script. Optional flags include `--seed`, `--max-updates`, `--output-dir`, `--train-data`, and `--test-data`. Audit-only mode writes the toy CSV and its summary; it does not run the digit experiment.

## Data and model conventions

Digit 1 maps to +1 and digit 6 to -1. The augmented input is `[1, intensity, asymmetry]`, where asymmetry is mean absolute left-right mirror difference. Initial weights are `[0,0,0]`; score >= 0 predicts +1, otherwise -1. The fixed digit datasets contain 1669 selected training examples (1005 ones and 664 sixes) and 434 test examples. The training-scatter plot uses a fixed-seed sample of 500 examples per class, or all if fewer exist.

The toy augmented matrix has rows `[[1,0,0], [1,0,0], [1,0,0], [1,1,0]]` with labels `[+1,-1,+1,-1]`. Using seed 0 and six updates, the saved current training errors for states 0 through 6 are `[.5,.5,.25,.5,.25,.5,.25]`; pocket errors are `[.5,.5,.25,.25,.25,.25,.25]`. The first two contradictory labels prove nonseparability.

## Generated reference evidence

`outputs/` contains `error_curves.png`, `decision_boundaries.png`, `trajectory.csv`, `toy_trace.csv`, and `summary.json`. The full digit reference run with seed 0 and 2000 updates gives:

| Model | Final weights | Training error | Test error |
| --- | --- | ---: | ---: |
| Current perceptron | `[2, -1.62247265625, -13.2635234375]` | 0.04014379868 | 0.07142857143 |
| Pocket | `[3, -0.90201171875, -12.8989765625]` | 0.03235470342 | 0.06451612903 |

Pocket test error increases at update 54 (0.06682027650 to 0.06912442396) and update 453 (0.05990783410 to 0.06451612903). These observations illustrate why the training-error guarantee does not imply monotone test error. Do not grade students by exact plot matching if they use a different permitted seed or implementation convention; grade their adherence to the stated assignment and evidence-backed explanation.

All 12 tests pass. They cover the score-zero convention, separable early stopping, initial-state/update counts, the exact six-update toy trace, selection of current mistakes, cumulative-minimum training error, corrupted-history detection, independent pocket/history copies, test-label independence, feature/label/bias construction, and preservation of the actual toy CSV when an audit fails. These checks and the numerical results are instructor reference material, not a fabricated AI interaction; students must report their own genuine interaction and verification.
