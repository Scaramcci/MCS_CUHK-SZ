# DDA5001 Homework 1: instructor code solutions for Problems 3 and 5

This is the instructor solution, not the student release. Distribute
`code_source` with `DDA5001-Homework1.tex` to students. Both code folders include
identical supplied datasets and scaffolding; the instructor version completes the mathematical and
verification TODOs and includes numerical tests and generated reference outputs.
No example AI conversation is fabricated: students must submit their real cases.

## Reproduce the results

Use Python 3.10 or later. From this folder:

```sh
python -m pip install -r requirements.txt
python p3/p3.py
python p5/p5.py
python -m unittest discover -s p3 -p 'test_*.py' -v
python -m unittest discover -s p5 -p 'test_*.py' -v
```

Default outputs go to `p3/outputs/` and `p5/outputs/`. The figures in the LaTeX
reference solution use these paths. The per-problem READMEs and `--help` document
the available options. Keep this folder beside `DDA5001_HW1_Solution.tex` when
compiling the reference document.

## Point allocation

| Problem | Part a | Part b | Part c | Part d | Part e | Total |
|---|---:|---:|---:|---:|---:|---:|
| P3 | 3 | 3 | 6 | 5 | 6 | 23 |
| P5 | 7 | 6 | 4 | 5 | 6 | 28 |

The homework totals 100 points: P1 = 12, P2 = 13, P3 = 23, P4 = 24,
and P5 = 28.

P3(d) assesses derivative validation and sum/mean scaling. P5(d) assesses the small
trace, running-minimum property, saved-state independence, and the distinction
between training and test guarantees. In both problems, part (e) awards 1 point
for a specific initial expectation/question, 2 for genuine interaction including
a follow-up based on actual evidence, and 3 for an evidence-supported judgment.
Chat length, number of screenshots, and forced debugging are not graded.

## Interpretation

The reference outputs illustrate one reproducible seed, not a universal ranking
of algorithms. P3 uses the question's shifted, scaled Huber **sum** loss and the
fixed baseline settings. P5 consistently uses an explicit bias, zero-score
prediction `+1`, training-only pocket selection, and a shared underlying update
trajectory for current and pocket weights.
